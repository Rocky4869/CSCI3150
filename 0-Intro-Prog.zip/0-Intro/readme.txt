1. Compile:  

   gcc -o x x.c -Wall
   gcc -o thread thread.c -Wall -pthread 
   

2. Run: ./x



In the above, x is the file name.
