void foo_func(int);
void bar_func(const char *);