#include <stdio.h>

void foo_func(int x) {
	printf("foo_func_test %d\n", x);
}