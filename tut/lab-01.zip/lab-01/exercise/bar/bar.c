#include <stdio.h>

void bar_func(const char * s) {
	printf("%s\n", s);
}