#include "include/foobar.h"

int main() {
	foo_func(100);
	bar_func("hello bar test");
}